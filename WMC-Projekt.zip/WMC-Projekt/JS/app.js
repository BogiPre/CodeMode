window.onload = () => {
    stationinsert();
    setTimeout(() => {
        languageinsert();
        countryinsert();
    }, 3000);
}

function countryinsert() {
    fetch("https://de1.api.radio-browser.info/json/countries")
        .then(response => response.json())
        .then(data => {
            let compareCountry1 = [];
            for (i = 0; i < data.length; i++) {
                compareCountry1.push(data[i].name);
            }
            let compareCountry2 = JSON.parse(sessionStorage.getItem("country"));
            let countries = [];
            for (i = 0; i < 300; i++) {
                if (compareCountry1.includes(compareCountry2[i]) && countries.includes(compareCountry2[i]) == false) {
                    countries.push(compareCountry2[i]);
                }
            }
            countries.sort();
            for (i = 0; i < countries.length; i++) {
                var row = `<option value = ${countries[i]}>  ${countries[i]} </option>`;
                document.querySelector("#countries").innerHTML += row;
            }
        })
    document.querySelector("#countries").addEventListener("change", () => {
        remove();
        countryfilter(document.querySelector("#countries").value);
    });
}


function languageinsert() {
    fetch("https://de1.api.radio-browser.info/json/languages")
        .then(response => response.json())
        .then(data => {
            let worldlang = [];
            for (i = 0; i < data.length; i++) {
                worldlang.push(data[i].name);
            }
            let insertLanguage = [];
            let testLanguage = JSON.parse(sessionStorage.getItem("language"));
            for (i = 0; i < testLanguage.length; i++) {
                if (isNaN(testLanguage[i]) == true && !testLanguage[i].includes("http")) {
                    if (worldlang.includes(testLanguage[i]) && insertLanguage.includes(testLanguage[i]) == false) {
                        insertLanguage.push(testLanguage[i]);
                    } else if (data.includes(testLanguage[i]) == false && testLanguage[i].localeCompare("") == 0) {
                        let stationcountry = JSON.parse(sessionStorage.getItem("country"));
                        for (lang = 0; lang < worldlang.length; lang++) {
                            if (stationcountry[i].contains(worldlang[lang].slice(0, 3))) {
                                testLanguage[i] = worldlang[lang];
                                if (insertLanguage.includes(testLanguage[i]) == false) {
                                    insertLanguage.push(testLanguage[i]);
                                }
                            }
                        }
                    }
                }
            }
            insertLanguage.sort();
            for (i = 0; i < insertLanguage.length; i++) {
                let nameToUpper = "";
                if (insertLanguage[i].match(" ") != null) {
                    let leer = insertLanguage[i].split(" ");
                    for (let up = 0; up < leer.length; up++) {
                        leer[up] = leer[up].charAt(0).toUpperCase() + leer[up].substr(1) + " ";
                        nameToUpper += leer[up];
                    }
                    var row = `<option value = ${JSON.stringify(insertLanguage[i])}>  ${nameToUpper} </option>`;
                    document.querySelector("#languages").innerHTML += row;
                    sessionStorage.setItem(insertLanguage[i], nameToUpper);
                } else {
                    nameToUpper = insertLanguage[i];
                    nameToUpper = nameToUpper.charAt(0).toUpperCase() + nameToUpper.substr(1);
                    var row = `<option value = ${JSON.stringify(insertLanguage[i])}>  ${nameToUpper} </option>`;
                    document.querySelector("#languages").innerHTML += row;
                    sessionStorage.setItem(insertLanguage[i], nameToUpper);
                }

            }
        })
    document.querySelector("#languages").addEventListener("change", () => {
        remove();
        languagefilter(document.querySelector("#languages").value);
    });
}



function stationinsert() {
    fetch("https://de1.api.radio-browser.info/json/stations")
        .then(response => response.json())
        .then(data => {
            let stations = [];
            let countries = [];
            let language = [];
            for (let i = 0; i < 300; i++) {
                let station = Math.floor(Math.random() * (31928 - 0 + 1)) + 0;
                countries.push(data[station].country);
                language.push(data[station].language);
                stations.push(data[station]);
                if (data[station].name.length < 45) {
                    var row = `<option value = ${JSON.stringify(data[station].name)}>  ${data[station].name} </option>`;
                    document.querySelector("#stations").innerHTML += row;
                }
            }
            let names = [];
            for (i = 0; i < stations.length; i++) {
                names.push(stations[i].name);
            }
            sessionStorage.setItem("stations", JSON.stringify(stations));
            sessionStorage.setItem("country", JSON.stringify(countries));
            sessionStorage.setItem("language", JSON.stringify(language));
            sessionStorage.setItem("name", JSON.stringify(names));
        })
    document.querySelector("#stations").addEventListener("change", () => {
        remove();
        stationfilter(document.querySelector("#stations").value);
    });
}

function countryfilter(country) {
    let result = false;
    let station = JSON.parse(sessionStorage.getItem("stations"));
    sessionStorage.setItem("station", JSON.stringify(station));
    let musicbox = [];
    for (let i = 0; i < station.length; i++) {
        if (station[i].country.includes(country)) {
            console.log(station[i].country);
            musicbox[i] = document.createElement("div");
            musicbox[i].className = "container bg-dark p-2 mx-5 text-white text-center sus";
            if (station[i].language.localeCompare("") == 0 || station[i].language == null && station[i].country.localeCompare(country) == 0) {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3> <p>Country: ${country}</p>`;
                document.querySelector("#stations").selectedIndex = 0;
                document.querySelector("#languages").selectedIndex = 0;
            } else if (station[i].language.localeCompare("") != 0 && station[i].language != null && !station[i].language.includes(",") &&
            station[i].country.localeCompare(country) == 0) {
                musicbox[i].innerHTML = `<h3>${station[i].name}
                 </h3>  <p>Language: ${sessionStorage.getItem(station[i].language)}
             <br> Country: ${station[i].country}</p>`;
                document.querySelector("#stations").selectedIndex = 0;
                document.querySelector("#languages").selectedIndex = 0;
            } else if (station[i].language.localeCompare("") != 0 && station[i].language != null && !station[i].language.includes(",") &&
            station[i].country.localeCompare(country) != 0)
                musicbox[i].innerHTML = `<h3>${station[i].name}
            </h3>  <p>Language: ${sessionStorage.getItem(station[i].language)}</p>`;
            document.querySelector("#stations").selectedIndex = 0;
            document.querySelector("#languages").selectedIndex = 0;

            let audio = document.createElement("audio");
            audio.setAttribute("controls", "preload");
            audio.src = station[i].url;
            musicbox[i].appendChild(audio);
            document.querySelector("#output").appendChild(musicbox[i]);
            result = true;
        }
    }
}


var rem = 0;

function remove() {
    rem++;
    if (rem > 1) {
        const boxes = document.querySelectorAll('.sus');
        boxes.forEach(box => {
            box.remove();
        });

    }
}

function languagefilter(language) {
    let result = false;
    let station = JSON.parse(sessionStorage.getItem("stations"));
    sessionStorage.setItem("station", JSON.stringify(station));
    let musicbox = [];
    console.log(language);
    for (let i = 0; i < station.length; i++) {
        if (station[i].language.includes(language)) {
            musicbox[i] = document.createElement("div");
            musicbox[i].className = "container bg-dark p-2 mx-5 text-white text-center sus";
            if (station[i].language.localeCompare(language) == 0) {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3> <p>Language: ${sessionStorage.getItem(language)}
             <br> Country: ${station[i].country}</p>`;
                document.querySelector("#stations").selectedIndex = 0;
                document.querySelector("#countries").selectedIndex = 0;
            } else {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3>
                 Country: ${station[i].country}</p>`;
                document.querySelector("#stations").selectedIndex = 0;
                document.querySelector("#countries").selectedIndex = 0;
            }
            let audio = document.createElement("audio");
            audio.setAttribute("controls", "preload");
            audio.src = station[i].url;
            musicbox[i].appendChild(audio);
            document.querySelector("#output").appendChild(musicbox[i]);
            result = true;
        }
    }
}

function stationfilter(stations) {
    let station = JSON.parse(sessionStorage.getItem("stations"));
    sessionStorage.setItem("station", JSON.stringify(station));
    let musicbox = [];
    for (let i = 0; i < station.length; i++) {
        if (station[i].name.includes(stations)) {
            musicbox[i] = document.createElement("div");
            musicbox[i].className = "container bg-dark p-2 mx-5 text-white text-center sus";
            if (station[i].language.localeCompare("") != 0 && station[i].country.localeCompare("") != 0 &&
                station[i].language != null && station[i].country != null) {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3> <p>Language: ${sessionStorage.getItem(station[i].language)}
             <br> Country: ${station[i].country}</p>`;
                document.querySelector("#languages").selectedIndex = 0;
                document.querySelector("#countries").selectedIndex = 0;
            } else if (station[i].language.localeCompare("") != 0 && station[i].language != null &&
                station[i].country.localeCompare("") == 0 || station[i].country == null && !station[i].language.includes(",")) {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3> <p>Language: ${sessionStorage.getItem(station[i].language)}</p>`;
                document.querySelector("#languages").selectedIndex = 0;
                document.querySelector("#countries").selectedIndex = 0;
            } else if (station[i].country.localeCompare("") != 0 && station[i].country != null &&
                station[i].language.localeCompare("") == 0 || station[i].language == null) {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3> <p>Country: ${station[i].country}</p>`;
                document.querySelector("#languages").selectedIndex = 0;
                document.querySelector("#countries").selectedIndex = 0;
            } else {
                musicbox[i].innerHTML = `<h3>${station[i].name}</h3>`;
                document.querySelector("#languages").selectedIndex = 0;
                document.querySelector("#countries").selectedIndex = 0;
            }
            let audio = document.createElement("audio");
            audio.setAttribute("controls", "preload");
            audio.src = station[i].url;
            musicbox[i].appendChild(audio);
            document.querySelector("#output").appendChild(musicbox[i]);
            result = true;
        }
    }
}

function searchfilter() {
    let input = document.querySelector("#search").value;
    let hold = document.querySelector("#search").placeholder;
    if (hold.includes("Language") && input.length > 3) {
        remove();
        let test1 = JSON.parse(sessionStorage.getItem("language"));
        let languages = [];
        for(i = 0; i < test1.length; i++){
            if(!languages.includes(test1[i])){
               languages.push(test1[i]);
            }
        }
        for (i = 0; i < languages.length; i++) {
            if (languages[i].includes(input)) {
                languagefilter(input);
                stop();
            }
        }
    } else if (hold.includes("Country") && input.length > 3) {
        remove();
        let test2 = JSON.parse(sessionStorage.getItem("country"));
        let countries = [];
        for(i = 0; i < test2.length; i++){
            if(!countries.includes(test2[i])){
               countries.push(test2[i]);
            }
        }
        for (i = 0; i < countries.length; i++) {
            if (countries[i].includes(input)) {
                countryfilter(input);
                stop();
            }
        }
    } else if (hold.includes("Station") && input.length > 1) {
        remove();
        let test3 = JSON.parse(sessionStorage.getItem("name"));
        let stations = [];
        for(i = 0; i < test3.length; i++){
            if(!stations.includes(test3[i])){
                stations.push(test3[i]);
            }
        }
        for (i = 0; i < stations.length; i++) {
            if (stations[i].includes(input)) {
                stationfilter(input);
                stop();
            }
        }
    }
}

function languagevalue() {
    document.querySelector("#search").placeholder = "Filter by Language";
}

function countryvalue() {
    document.querySelector("#search").placeholder = "Filter by Country";
}

function stationvalue() {
    document.querySelector("#search").placeholder = "Filter by Station";
}