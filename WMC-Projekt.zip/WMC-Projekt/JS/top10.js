window.onload = () => {
    document
    .querySelector('#btn-load-list')
    .addEventListener('click', () => stationsByVotes());
    sessionStorage.setItem("CurrentLoaded", 0);
    console.log("Wird aufgerufen")
    
}
//http://91.132.145.114/json/stations/topvote
  stations= [];

function stationsByVotes() {
    fetch("http://91.132.145.114/json/stations/topvote/100")
        .then(response => response.json())
        .then(data => {
            sessionStorage.setItem("TopStations", JSON.stringify(data));
            let update = JSON.parse(sessionStorage.getItem("CurrentLoaded"));
            console.log("Update:" +update)

            console.log("DIE LÄNGE"+ stations.length)
            if(stations.length == 0){
                stations = JSON.parse(sessionStorage.getItem("TopStations"));
                console.log("Ja ist nan")
            }
            //alte implementation
            //`<button class="btn btn-warning" onclick="playAudio(${i})"  id="btn-play"> </button>`+
            for (let i = update; i < update+5 ; i++) {

                 var audio = new Audio(data[i].url); 
                 audio.type = 'audio/wav';

                let zahl = i +1;
                let URL = JSON.stringify(audio);
                var row = `<li> <div> <time>${zahl}</time><h5>${data[i].name}</h5>
                <h6>Sprache: ${data[i].language} </h6> 
                <h6>Land: ${data[i].country} <a type="button" href="visualizer.html" onclick="saveIdxToStorage(${i})" class="btn btn-sm btn-outline-danger btn-sm">Visualize</a><h6>
                <audio src="${audio.src} "  class="audio-player" controls></audio>
                
                </div></li>`;
                document.querySelector("#ListeTop").innerHTML += row;
                console.log(audio);
                console.log(`${URL}`);
            }

            
           check();
           update += 5;
           if(update == 100){
             var button=document.querySelector("#btn-load-list");
             button.remove();
               console.log("removed");
           }
           sessionStorage.removeItem("CurrentLoaded")
           sessionStorage.setItem("CurrentLoaded", update);
           console.log("Session After:" +sessionStorage.getItem("CurrentLoaded"))
        })
    }



    function saveIdxToStorage(idx){
      sessionStorage.setItem("currIdx", JSON.stringify(idx));
    }
  //    Alte implementation (vor dem Wissen vom Audio player D;)  Stunden habe ich gedebuggt bis es irgendwie geht nur dann festzustellen, dass es so viel einfacher geht
/*
    function playAudio(data) {
    
    console.log(stations)
    var audio = new Audio(stations[data].url); 
    console.log(stations[data].url) 
    audio.type = 'audio/wav';
  
    try {
      audio.play();
      console.log('Playing...');
    } catch (err) {
      console.log('Failed to play...' + err);
    }
  }

*/
function check() {
    "use strict";
    // define variables
    var items = document.querySelectorAll(".timeline li");


    function isElementInViewport(el) {
        var rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <=
            (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    function callbackFunc() {
        for (var i = 0; i < items.length; i++) {
            if (isElementInViewport(items[i])) {
                items[i].classList.add("in-view");
            }
        }
    }

    // listen for events
    window.addEventListener("load", callbackFunc);
    window.addEventListener("resize", callbackFunc);
    window.addEventListener("scroll", callbackFunc);
};